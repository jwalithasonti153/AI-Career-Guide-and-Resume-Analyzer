# AI Career Guide & Resume Analyzer

A single-page Flask web application with two sections:

1. **AI Career Guide**
   - Full name
   - Skill set
   - Target role
   - Personalized 30-day preparation plan
   - Learning resources
   - Job portals
   - Interview tips

2. **Resume Analyzer**
   - PDF/DOCX/TXT upload
   - Target role
   - Positives and negatives
   - Resume improvement areas
   - Estimated ATS score
   - Keyword hints
   - Job portals
   - ATS-friendly resume builder links

## Tech stack

- Frontend: HTML, CSS, JavaScript
- Backend: Python Flask
- Data format: JSON
- AI: OpenAI Responses API
- Resume parsing: pypdf + python-docx

## Project structure

```text
ai_career_guide_resume_analyzer/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── app.js
```

## Run locally

### 1. Create a virtual environment

Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install packages

```bash
pip install -r requirements.txt
```

### 3. Configure API key

Copy `.env.example` to `.env` and put your API key in:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-5.6-luna
```

Never put the API key in HTML, CSS, JavaScript, GitHub, or a public repository.

### 4. Start the app

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## API performance choices

- The browser never receives the API key.
- One backend AI request is made per submitted operation.
- A lightweight heuristic ATS calculation runs locally before/alongside AI analysis.
- Resume input is capped at 5 MB.
- The AI prompt limits resume text to a reasonable size.
- If the API is unavailable or no key is configured, the app still returns a useful rule-based fallback.
- For production, set `debug=False` and add authentication/rate limiting before exposing the app publicly.

## Important ATS note

The ATS score is an estimate. Different Applicant Tracking Systems use different parsing and matching rules, so no third-party website can guarantee an exact score for every employer.

## Suggested demo flow

1. Open the single-page website.
2. Click **AI Career Guide**.
3. Fill name, skills and target role.
4. Click **Generate 30-Day Plan**.
5. Review the plan/resources/job portals.
6. Scroll to **Resume Analyzer**.
7. Upload PDF/DOCX/TXT resume and enter target role.
8. Click **Analyze Resume**.
9. Review ATS estimate, positives, negatives, improvement areas and links.
