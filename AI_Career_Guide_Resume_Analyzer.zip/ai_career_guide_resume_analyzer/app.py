import os
import json
import re
from pathlib import Path

from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}

RESOURCES = [
    {"name": "W3Schools", "url": "https://www.w3schools.com/"},
    {"name": "GeeksforGeeks", "url": "https://www.geeksforgeeks.org/"},
    {"name": "freeCodeCamp", "url": "https://www.freecodecamp.org/"},
    {"name": "Kaggle Learn", "url": "https://www.kaggle.com/learn"},
]

JOB_PORTALS = [
    {"name": "LinkedIn Jobs", "url": "https://www.linkedin.com/jobs/"},
    {"name": "Naukri", "url": "https://www.naukri.com/"},
    {"name": "Indeed India", "url": "https://in.indeed.com/"},
    {"name": "Foundit", "url": "https://www.foundit.in/"},
    {"name": "Wellfound", "url": "https://wellfound.com/jobs"},
]

RESUME_TOOLS = [
    {"name": "Canva Resume Builder", "url": "https://www.canva.com/create/resumes/"},
    {"name": "Novorésumé", "url": "https://novoresume.com/"},
    {"name": "Reactive Resume", "url": "https://rxresu.me/"},
]

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_resume_text(file_storage):
    ext = file_storage.filename.rsplit(".", 1)[1].lower()
    data = file_storage.read()

    if ext == "txt":
        return data.decode("utf-8", errors="ignore")

    if ext == "pdf":
        from pypdf import PdfReader
        import io
        reader = PdfReader(io.BytesIO(data))
        return "\n".join(page.extract_text() or "" for page in reader.pages)

    if ext == "docx":
        from docx import Document
        import io
        doc = Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs)

    raise ValueError("Unsupported file type.")

def heuristic_ats(resume_text, target_role):
    text = resume_text.lower()
    role_words = re.findall(r"[a-zA-Z][a-zA-Z+#.\-]{2,}", target_role.lower())
    common_keywords = list(dict.fromkeys(role_words))
    technical = [
        "python", "sql", "excel", "power bi", "tableau", "java", "javascript",
        "html", "css", "react", "git", "github", "pandas", "numpy", "flask",
        "machine learning", "data analysis", "communication", "project"
    ]
    found = [k for k in technical if k in text]
    role_hits = [k for k in common_keywords if k in text]

    score = 35
    score += min(30, len(found) * 3)
    score += min(20, len(role_hits) * 4)

    sections = ["education", "skills", "project", "experience"]
    section_hits = sum(1 for s in sections if s in text)
    score += section_hits * 3

    if re.search(r"\b(email|phone|mobile)\b", text):
        score += 2
    if len(resume_text.split()) >= 180:
        score += 2

    score = max(0, min(100, score))

    positives = []
    negatives = []
    improvements = []

    if found:
        positives.append("Contains relevant technical keywords: " + ", ".join(found[:8]) + ".")
    else:
        negatives.append("Few recognizable technical keywords were found.")

    if section_hits >= 3:
        positives.append("Core resume sections such as education, skills, projects, and/or experience are present.")
    else:
        negatives.append("Some standard ATS sections appear to be missing or unclear.")

    if role_hits:
        positives.append("Some target-role terms are present.")
    else:
        improvements.append("Add target-role keywords naturally in the Summary, Skills, Projects, and Experience sections.")

    if len(resume_text.split()) < 150:
        improvements.append("Add measurable project or internship details so the resume has enough evidence of impact.")
    if not re.search(r"\b\d+%|\b\d+\+|\b\d+\b", resume_text):
        improvements.append("Add quantified achievements where truthful, such as percentages, counts, time saved, or records processed.")

    improvements.extend([
        "Use simple headings and bullet points; avoid tables, text boxes, graphics, and multi-column layouts for ATS reliability.",
        "Mirror important keywords from the job description only when they accurately describe your skills.",
        "Keep contact details in the main document body rather than headers/footers when possible."
    ])

    return {
        "ats_score": score,
        "positives": positives,
        "negatives": negatives,
        "improvement_areas": improvements,
        "keyword_hints": sorted(set(found + role_hits))[:20],
    }

def get_openai_client():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    from openai import OpenAI
    return OpenAI(api_key=api_key)

def call_ai(prompt):
    client = get_openai_client()
    if not client:
        return None

    model = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
    response = client.responses.create(
        model=model,
        input=prompt,
    )
    raw = response.output_text.strip()

    # Tolerate markdown code fences around JSON.
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
    raw = re.sub(r"\s*```$", "", raw)
    return json.loads(raw)

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/career-guide")
def career_guide():
    data = request.get_json(silent=True) or {}
    name = data.get("fullname", "").strip()
    skills = data.get("skills", "").strip()
    role = data.get("target_role", "").strip()

    if not name or not skills or not role:
        return jsonify({"error": "Please fill Full Name, Skill Set and Target Role."}), 400

    prompt = f"""
You are an AI career coach. Create a practical 30-day plan for a learner.
Name: {name}
Skills: {skills}
Target role: {role}

Return ONLY valid JSON with this exact structure:
{{
  "summary": "short personalized guidance",
  "30_day_plan": [
    {{"day": 1, "focus": "...", "tasks": ["...", "..."], "deliverable": "..."}}
  ],
  "resources": [{{"name": "...", "url": "https://..."}}],
  "job_portals": [{{"name": "...", "url": "https://..."}}],
  "interview_tips": ["...", "..."]
}}

The plan must contain exactly 30 day objects. Prefer well-known learning resources and job portals.
Do not invent URLs. If uncertain about a URL, use one of the provided verified resources/job portals.
"""
    try:
        result = call_ai(prompt)
        if result:
            return jsonify(result)
    except Exception:
        pass

    # Fast fallback if API is not configured or temporarily unavailable.
    plan = []
    phases = [
        ("Foundation", "Revise fundamentals and identify gaps."),
        ("Core practice", "Solve focused exercises and build small examples."),
        ("Project", "Build or improve a role-relevant project."),
        ("Portfolio", "Document the project and publish your work."),
        ("Interview", "Practice technical and HR questions."),
        ("Applications", "Tailor the resume and start applying."),
    ]
    for day in range(1, 31):
        phase, focus = phases[(day - 1) // 5]
        plan.append({
            "day": day,
            "focus": f"{phase}: {focus}",
            "tasks": [
                f"Study/practice {skills} with focus on {role}.",
                "Write down 3 key learnings and 1 question to revisit."
            ],
            "deliverable": "One small proof of work, note, solution, or portfolio update."
        })
    return jsonify({
        "summary": f"{name}, focus your preparation on the skills needed for {role}, then prove them through projects and interview practice.",
        "30_day_plan": plan,
        "resources": RESOURCES,
        "job_portals": JOB_PORTALS,
        "interview_tips": [
            "Prepare a 60-second self-introduction connected to the target role.",
            "Be ready to explain every project and technology listed on your resume.",
            "Practice SQL/Python/role-specific questions and behavioral examples."
        ]
    })

@app.post("/api/resume-analyzer")
def resume_analyzer():
    if "resume" not in request.files:
        return jsonify({"error": "Please upload a PDF, DOCX or TXT resume."}), 400

    file = request.files["resume"]
    target_role = request.form.get("target_role", "").strip()

    if not file.filename or not allowed_file(file.filename):
        return jsonify({"error": "Allowed resume formats: PDF, DOCX, TXT."}), 400
    if not target_role:
        return jsonify({"error": "Please enter a target role."}), 400

    try:
        resume_text = extract_resume_text(file)
    except Exception as exc:
        return jsonify({"error": f"Could not read the resume: {exc}"}), 400

    if len(resume_text.strip()) < 50:
        return jsonify({"error": "Very little text was extracted. If this is a scanned PDF, use a text-based PDF or DOCX."}), 400

    heuristic = heuristic_ats(resume_text, target_role)

    prompt = f"""
Analyze this resume for the target role: {target_role}

Resume text:
{resume_text[:18000]}

Return ONLY valid JSON:
{{
  "summary": "short assessment",
  "positives": ["..."],
  "negatives": ["..."],
  "improvement_areas": ["..."],
  "ats_score": 0,
  "ats_explanation": "why this score was given",
  "missing_keywords": ["..."],
  "job_portals": [{{"name":"...","url":"https://..."}}],
  "ats_resume_tools": [{{"name":"...","url":"https://..."}}]
}}

ATS score should be a cautious estimate, not a guarantee. Do not claim to be an official ATS.
Do not invent job portal or resume-builder URLs; use these verified options where relevant:
{json.dumps(JOB_PORTALS + RESUME_TOOLS)}
"""
    try:
        ai = call_ai(prompt)
    except Exception:
        ai = None

    if ai:
        # Keep the score within a sensible range and expose the heuristic too.
        ai["ats_score"] = max(0, min(100, int(ai.get("ats_score", heuristic["ats_score"]))))
        ai.setdefault("job_portals", JOB_PORTALS)
        ai.setdefault("ats_resume_tools", RESUME_TOOLS)
        ai["heuristic_ats_score"] = heuristic["ats_score"]
        return jsonify(ai)

    return jsonify({
        "summary": "Rule-based resume analysis completed. Add an OpenAI API key for deeper AI analysis.",
        "positives": heuristic["positives"],
        "negatives": heuristic["negatives"],
        "improvement_areas": heuristic["improvement_areas"],
        "ats_score": heuristic["ats_score"],
        "ats_explanation": "This is a heuristic estimate based on keywords and common resume sections, not an official ATS score.",
        "missing_keywords": [],
        "job_portals": JOB_PORTALS,
        "ats_resume_tools": RESUME_TOOLS,
        "heuristic_ats_score": heuristic["ats_score"]
    })

@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "Resume is too large. Maximum upload size is 5 MB."}), 413

if __name__ == "__main__":
    app.run(debug=True)
