const $ = (id) => document.getElementById(id);

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

function links(items = []) {
  return `<div class="link-list">${items.map(x =>
    `<a class="link-chip" href="${escapeHtml(x.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(x.name)}</a>`
  ).join("")}</div>`;
}

function list(items = []) {
  return `<ul class="list">${items.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>`;
}

$("careerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = $("careerStatus");
  const output = $("careerOutput");
  status.className = "status loading";
  status.textContent = "Creating your personalized 30-day roadmap...";
  output.classList.add("hidden");

  try {
    const res = await fetch("/api/career-guide", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({
        fullname: $("fullname").value,
        skills: $("skills").value,
        target_role: $("targetRole").value
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Something went wrong.");

    output.innerHTML = `
      <div class="card result-card">
        <h3>Your Career Guide</h3>
        <p>${escapeHtml(data.summary)}</p>
      </div>
      <div class="card result-card">
        <h3>30-Day Plan</h3>
        <div class="plan">${(data["30_day_plan"] || []).map(day => `
          <div class="day">
            <div class="day-top"><span class="day-num">DAY ${escapeHtml(day.day)}</span></div>
            <h4>${escapeHtml(day.focus)}</h4>
            <ul>${(day.tasks || []).map(t => `<li>${escapeHtml(t)}</li>`).join("")}</ul>
            <p><strong>Deliverable:</strong> ${escapeHtml(day.deliverable)}</p>
          </div>`).join("")}</div>
      </div>
      <div class="grid-2">
        <div class="card result-card"><h3>Learning Resources</h3>${links(data.resources)}</div>
        <div class="card result-card"><h3>Job Portals</h3>${links(data.job_portals)}</div>
      </div>
      <div class="card result-card"><h3>Interview Tips</h3>${list(data.interview_tips)}</div>
    `;
    output.classList.remove("hidden");
    status.className = "status";
    status.textContent = "Plan generated successfully.";
    output.scrollIntoView({behavior:"smooth", block:"start"});
  } catch (err) {
    status.className = "status error";
    status.textContent = err.message;
  }
});

$("resumeForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = $("resumeStatus");
  const output = $("resumeOutput");
  const file = $("resumeFile").files[0];

  if (!file) {
    status.className = "status error";
    status.textContent = "Please choose a resume file.";
    return;
  }
  if (file.size > 5 * 1024 * 1024) {
    status.className = "status error";
    status.textContent = "Maximum file size is 5 MB.";
    return;
  }

  status.className = "status loading";
  status.textContent = "Reading and analyzing your resume...";
  output.classList.add("hidden");

  const form = new FormData();
  form.append("resume", file);
  form.append("target_role", $("resumeRole").value);

  try {
    const res = await fetch("/api/resume-analyzer", {method:"POST", body:form});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Analysis failed.");

    const score = Number(data.ats_score || 0);
    const keywords = (data.missing_keywords || data.keyword_hints || []).slice(0, 20);

    output.innerHTML = `
      <div class="card result-card">
        <div class="score-wrap">
          <div class="score" style="--score:${score}"><strong>${score}</strong></div>
          <div><h3>Estimated ATS Score</h3><p>${escapeHtml(data.ats_explanation || "Estimated from resume structure, keywords and target-role relevance.")}</p></div>
        </div>
      </div>
      <div class="card result-card"><h3>Overall Assessment</h3><p>${escapeHtml(data.summary || "")}</p></div>
      <div class="grid-2">
        <div class="card result-card good"><h3>✓ Positives</h3>${list(data.positives)}</div>
        <div class="card result-card bad"><h3>✕ Negatives</h3>${list(data.negatives)}</div>
      </div>
      <div class="card result-card"><h3>Improvement Areas</h3>${list(data.improvement_areas)}</div>
      ${keywords.length ? `<div class="card result-card"><h3>Keyword Hints</h3>${keywords.map(k => `<span class="keyword">${escapeHtml(k)}</span>`).join("")}</div>` : ""}
      <div class="grid-2">
        <div class="card result-card"><h3>Job Portals</h3>${links(data.job_portals)}</div>
        <div class="card result-card"><h3>ATS-Friendly Resume Tools</h3>${links(data.ats_resume_tools)}</div>
      </div>
    `;
    output.classList.remove("hidden");
    status.className = "status";
    status.textContent = "Resume analysis completed.";
    output.scrollIntoView({behavior:"smooth", block:"start"});
  } catch (err) {
    status.className = "status error";
    status.textContent = err.message;
  }
});
